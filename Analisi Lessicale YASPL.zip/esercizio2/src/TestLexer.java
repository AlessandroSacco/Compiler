
import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import java_cup.runtime.Symbol;



public class TestLexer {
   
  public static void main(String argv[]) {
	int id=-1;
    for (int i = 0; i < argv.length; i++) {
      try {
       System.out.println("Lexing ["+argv[i]+"]\n");
       Lexer l= new Lexer(new FileReader(argv[i]));
       Symbol s=null;     
       do{
    	   //inseriamo nella hashmap
    	   s = l.next_token();
    	   l.insertH(id,l.yytext());   
    	   //stampa
    	   for (int j = 0; j < TOKEN_IDS.length; j++) {
    		   if(s.sym==TOKEN_IDS[j])
    			   System.out.println("("+l.yytext()+","+TOKEN_NAMES[j]+")");
    	   }
        } while (s.sym != sym.EOF);
        System.out.println("No errors.");	
      }
      catch (Exception e) {
    	  e.printStackTrace(System.out);
    	  System.exit(1);
      }
    }   
  }

  private static final String[] TOKEN_NAMES = new String[] {"SHORT","IDENTIFIER","ANDEQ","GT","IMPLEMENTS","NOTEQ","PLUSEQ","RBRACK","CATCH","SEPA","RBRACE","THROW","RPAREN","LBRACK","LT","ANDAND","OROR","DOUBLE","LBRACE","TRANSIENT","LPAREN","XOREQ","PROTECTED","INTEGER_LITERAL","NOT","FINAL","FLOAT","URSHIFTEQ","PACKAGE","COMP","EQ","BOOLEAN_LITERAL","MOD","CLASS","SUPER","ABSTRACT","NATIVE","LONG","PLUS","QUESTION","WHILE","EXTENDS","INTERFACE","CHAR","BOOLEAN","SWITCH","DO","FOR","RSHIFTEQ","VOID","DIV","PUBLIC","RETURN","MULT","ELSE","TRY","GTEQ","BREAK","DOT","INT","NULL_LITERAL","THROWS","STRING_LITERAL","EQEQ","EOF","SEMICOLON","THIS","DEFAULT","MULTEQ","IMPORT","MINUS","LTEQ","OR","error","URSHIFT","SYNCHRONIZED","DIVEQ","LSHIFTEQ","FINALLY","CONTINUE","INSTANCEOF","IF","MODEQ","MINUSMINUS","COLON","CHARACTER_LITERAL","OREQ","VOLATILE","CASE","PLUSPLUS","NEW","RSHIFT","BYTE","AND","PRIVATE","STATIC","LSHIFT","XOR","FLOATING_POINT_LITERAL","MINUSEQ","ASSIGN","READ","WRITE","END","BEGIN","FI","ROF","ELIHW","ESLE"};
  private static final Integer[] TOKEN_IDS = new Integer[]  {4,98,90,70,36,75,85,11,55,15,17,53,20,10,69,79,80,9,16,32,19,91,25,93,63,29,8,89,22,62,18,95,65,34,40,28,30,6,60,81,48,35,41,7,2,44,47,49,88,37,64,24,52,14,43,54,72,50,12,5,99,38,97,74,0,13,39,46,82,23,61,71,78,1,68,31,83,87,56,51,73,42,84,59,21,96,92,33,45,58,57,67,3,76,26,27,66,77,94,86,100,101,102,103,104,105,106,107,108};
} 



//nel caso vogliamo stampare la tabella dei simboli

/* HashMap<Integer, String> app = new HashMap<Integer, String>();
app=l.stampH();
System.out.println(app.size());
// Avvio il ciclo su tutti gli elementi (entry)
// della mappa (map.entrySet())
for (Entry<Integer, String> entry : app.entrySet()) { 
// Stampo le coppie chiave-valore
System.out.println("Key = " + entry.getKey());
System.out.println("Value = " + entry.getValue()); 
} */