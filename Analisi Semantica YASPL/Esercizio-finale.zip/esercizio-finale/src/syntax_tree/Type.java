package syntax_tree;

public enum Type{
		BOOLEAN,
		INTEGER,
		STRING,
		VOID
	}

