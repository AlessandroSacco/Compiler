package syntax_tree;

 

import xmlvisitor.Visitable;
import xmlvisitor.Visitor;

public class UnaryMinusOp extends SimpleExpression implements Visitable{
	public SimpleExpression sExpr;

	public UnaryMinusOp(SimpleExpression sExpr) {
		super();
		this.sExpr = sExpr;
	}
	@Override
	public Object accept(Visitor v) {
		return v.visit(this);
	}
	public String toString()
	{
		return "-"+sExpr.toString();
	}
}
