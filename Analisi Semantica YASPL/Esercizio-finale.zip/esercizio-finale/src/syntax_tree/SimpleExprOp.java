package syntax_tree;

 

import xmlvisitor.Visitable;
import xmlvisitor.Visitor;

public class SimpleExprOp extends Expression implements Visitable{
	public SimpleExpression sExpression;

	public SimpleExprOp(SimpleExpression sExpression) {
		super();
		this.sExpression = sExpression;
	}
	@Override
	public Object accept(Visitor v) {
		return v.visit(this);
	}
}
