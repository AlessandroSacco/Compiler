package syntax_tree;

 

import xmlvisitor.Visitable;
import xmlvisitor.Visitor;

public class WhileOp extends Stat implements Visitable{
	public Expression expr;
	public Stat stat;
	public WhileOp(Expression expr, Stat stat) {
		super();
		this.expr = expr;
		this.stat = stat;
	}
	@Override
	public Object accept(Visitor v) {
		return v.visit(this);
	}
}
