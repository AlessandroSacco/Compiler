package syntax_tree;
import xmlvisitor.Visitable;
import xmlvisitor.Visitor;

public class Stat extends Root implements Visitable {

	public Object accept(Visitor v) {
		return null;
	}

}
