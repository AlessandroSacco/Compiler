package syntax_tree;

 

import xmlvisitor.Visitable;
import xmlvisitor.Visitor;

public class RelationalOp extends Expression implements Visitable{
	public String relOp;
	public SimpleExpression sExpr1,sExpr2;
	public RelationalOp( SimpleExpression sExpr1, String relOp, SimpleExpression sExpr2) {
		super();
		this.relOp = relOp;
		this.sExpr1 = sExpr1;
		this.sExpr2 = sExpr2;
	}
	@Override
	public Object accept(Visitor v) {
		return v.visit(this);
	}
	public String toString()
	{
		return sExpr1.toString()+relOp+sExpr2.toString();
	}
}
