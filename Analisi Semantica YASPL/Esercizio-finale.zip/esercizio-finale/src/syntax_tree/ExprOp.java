package syntax_tree;

import xmlvisitor.Visitable;
import xmlvisitor.Visitor;

public class ExprOp extends SimpleExpression implements Visitable{
	public Expression expr;

	public ExprOp(Expression expr) {
		super();
		this.expr = expr;
	}
	@Override
	public Object accept(Visitor v) {
		return v.visit(this);
	}
	@Override
	public String toString()
	{
		return expr.toString();
	}
	
}
