package syntax_tree;

import xmlvisitor.Visitable;
import xmlvisitor.Visitor;

public class Expression extends Root implements Visitable{
	
	Type type;
	public Type getType() {
		return type;
	}
	public void setType(Type type) {
		this.type = type;
	}
	@Override
	public Object accept(Visitor v) {
		// TODO Auto-generated method stub
		return null;
	}
	public String toString()
	{
		return null;
	}
}
