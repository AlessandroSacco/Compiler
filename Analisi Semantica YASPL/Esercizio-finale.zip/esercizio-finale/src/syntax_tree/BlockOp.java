package syntax_tree;

 

import xmlvisitor.Visitable;
import xmlvisitor.Visitor;

public class BlockOp extends Root implements Visitable{
	public VarDeclPartOp vdpRef;
	public ProcDeclPartOp pdpRef;
	public CompStatOp spRef;

	public BlockOp(VarDeclPartOp vdpRef, ProcDeclPartOp pdpRef, CompStatOp spRef) {
		super();
		this.vdpRef = vdpRef;
		this.pdpRef = pdpRef;
		this.spRef = spRef;
	}
	@Override
	public Object accept(Visitor v) {
		return v.visit(this);
	}
}
