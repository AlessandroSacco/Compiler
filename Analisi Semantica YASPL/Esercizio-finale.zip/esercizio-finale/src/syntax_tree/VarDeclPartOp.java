package syntax_tree;
import java.util.ArrayList;

 

import xmlvisitor.Visitable;
import xmlvisitor.Visitor;

public class VarDeclPartOp extends Root implements Visitable{
	public ArrayList<VarDeclOp> vdList;

	public VarDeclPartOp(ArrayList<VarDeclOp> vdList) {
		super();
		this.vdList = vdList;
	}
	@Override
	public Object accept(Visitor v) {
		
		return v.visit(this);
	}
	
	public void add(VarDeclOp vDecl) {
		// TODO Auto-generated method stub
		vdList.add(vDecl);
	}
}
