package syntax_tree;

 

import xmlvisitor.Visitable;
import xmlvisitor.Visitor;

public class SimpleBlockOp extends Root implements Visitable{
	public VarDeclPartOp vdPart;
	public CompStatOp cStat;
	public SimpleBlockOp(VarDeclPartOp vdPart, CompStatOp cStat) {
		super();
		this.vdPart = vdPart;
		this.cStat = cStat;
	}
	@Override
	public Object accept(Visitor v) {
		return v.visit(this);
	}
}
