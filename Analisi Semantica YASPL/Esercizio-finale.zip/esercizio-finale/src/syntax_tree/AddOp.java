package syntax_tree;

import xmlvisitor.Visitable;
import xmlvisitor.Visitor;

public class AddOp extends SimpleExpression implements Visitable{
	public String addingOp;
	public SimpleExpression sExpr1;
	public SimpleExpression sExpr2;
	public AddOp( SimpleExpression sExpr1,String addingOp, SimpleExpression sExpr2) {
		super();
		this.addingOp = addingOp;
		this.sExpr1 = sExpr1;
		this.sExpr2 = sExpr2;
	}
	@Override
	public Object accept(Visitor v) {
		return v.visit(this);
	}
	@Override
	public String toString()
	{
		return sExpr1.toString()+addingOp+sExpr2.toString();
	}
}
