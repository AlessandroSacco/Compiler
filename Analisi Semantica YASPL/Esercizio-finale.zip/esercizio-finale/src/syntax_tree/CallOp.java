package syntax_tree;

 

import xmlvisitor.Visitable;
import xmlvisitor.Visitor;

public class CallOp extends Stat implements Visitable{
	public String identifier;

	public CallOp(String identifier) {
		super();
		this.identifier = identifier;
	}
	@Override
	public Object accept(Visitor v) {
		return v.visit(this);
	}
	public String toString()
	{
		return identifier;
	}
}
