package syntax_tree;

 

import xmlvisitor.Visitable;
import xmlvisitor.Visitor;

public class ConstOp extends SimpleExpression implements Visitable{
	public String constant;
	public Type type;

	public Type getType() {
		return type;
	}
	public void setType(Type type) {
		this.type = type;
	}
	public ConstOp(String constant, Type type) {
		super();
		this.constant = constant;
		this.type = type;
	}
	@Override
	public Object accept(Visitor v) {
		return v.visit(this);
	}
	public String toString()
	{
		return constant;
	}
}
