package syntax_tree;

 

import xmlvisitor.Visitable;
import xmlvisitor.Visitor;

public class ProcDeclOp extends Root implements Visitable{
	public int identifier;
	public SimpleBlockOp sblock;
	public ProcDeclOp(int identifier, SimpleBlockOp sblock) {
		super();
		this.identifier = identifier;
		this.sblock = sblock;
	}
	@Override
	public Object accept(Visitor v) {
		return v.visit(this);
	}
}
