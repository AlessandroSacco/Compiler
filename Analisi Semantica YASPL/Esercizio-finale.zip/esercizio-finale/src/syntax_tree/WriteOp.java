package syntax_tree;
import java.util.ArrayList;

import xmlvisitor.Visitable;
import xmlvisitor.Visitor;

public class WriteOp extends Stat implements Visitable{
	public ArrayList<Expression> eList;

	public WriteOp(ArrayList<Expression> eList) {
		super();
		this.eList = eList;
	}
	@Override
	public Object accept(Visitor v) {
		return v.visit(this);
	}
	public void add(Expression expr) {
		// TODO Auto-generated method stub
		eList.add(expr);
	}
	
}
