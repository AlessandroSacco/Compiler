package syntax_tree;
import java.util.ArrayList;

 

import xmlvisitor.Visitable;
import xmlvisitor.Visitor;

public class VarDeclOp extends Root implements Visitable{
	public String type;
	public ArrayList<VarOp> vList;
	public VarDeclOp(String type, ArrayList<VarOp> vList) {
		super();
		this.type = type;
		this.vList = vList;
	}
	@Override
	public Object accept(Visitor v) {
		return v.visit(this);
	}
	
	public void add(VarOp v)
	{
		vList.add(v);
	}
}
