package syntax_tree;
import java.util.ArrayList;

 

import xmlvisitor.Visitable;
import xmlvisitor.Visitor;

public class ProcDeclPartOp extends Root implements Visitable{
	public ArrayList<ProcDeclOp> pdList;

	public ProcDeclPartOp(ArrayList<ProcDeclOp> pdList) {
		super();
		this.pdList = pdList;
	}
	@Override
	public Object accept(Visitor v) {
		return v.visit(this);
	}
	public void add(ProcDeclOp el)
	{
		ArrayList<ProcDeclOp> newList = new ArrayList<ProcDeclOp>();
		newList.add(el);
		newList.addAll(pdList);
		pdList = newList;
	}
}
