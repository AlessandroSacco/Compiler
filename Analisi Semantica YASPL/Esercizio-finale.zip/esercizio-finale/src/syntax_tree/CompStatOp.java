package syntax_tree;
import java.util.ArrayList;

 

import xmlvisitor.Visitable;
import xmlvisitor.Visitor;

public class CompStatOp extends Stat implements Visitable{
	public ArrayList<Stat> sList;

	public CompStatOp(ArrayList<Stat> sList) {
		super();
		this.sList = sList;
	}
	@Override
	public Object accept(Visitor v) {
		return v.visit(this);
	}
}
