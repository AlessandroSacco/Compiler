package syntax_tree;

 

import xmlvisitor.Visitable;
import xmlvisitor.Visitor;

public class NotOp extends SimpleExpression implements Visitable{
	public Expression expr;
	public NotOp(Expression expr)
	{
		this.expr = expr;
	}
	@Override
	public Object accept(Visitor v) {
		return v.visit(this);
	}
	public String toString()
	{
		return "!"+expr.toString();
	}
	
}
