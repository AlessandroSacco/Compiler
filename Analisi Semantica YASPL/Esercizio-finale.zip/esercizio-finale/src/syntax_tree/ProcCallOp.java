package syntax_tree;

 

import semantic_analysis.StringTable;
import xmlvisitor.Visitor;

public class ProcCallOp extends Stat {

	public int identifier;
	
	public ProcCallOp(int id)
	{
		this.identifier = id;
	}
	public Object accept(Visitor v) {
		return v.visit(this);
	}
	public String toString()
	{
		return StringTable.getInstance().getId(identifier);
	}
}
