package syntax_tree;

 

import xmlvisitor.Visitable;
import xmlvisitor.Visitor;

public class AssignOp extends Stat implements Visitable{
	public VarOp identifier;
	public Expression expr;
	public AssignOp(VarOp identifier, Expression expr) {
		super();
		this.identifier = identifier;
		this.expr = expr;
	}
	@Override
	public Object accept(Visitor v) {
		return v.visit(this);
	}
	public String toString()
	{
		return identifier.toString()+":="+expr.toString();
	}
	
}
