package syntax_tree;

 

import semantic_analysis.StringTable;
import xmlvisitor.Visitable;
import xmlvisitor.Visitor;

public class VarOp extends SimpleExpression implements Visitable{
	public int identifier;

	public VarOp(int identifier) {
		super();
		this.identifier = identifier;
	}
	@Override
	public Object accept(Visitor v) {
		return v.visit(this);
	}
	public String toString()
	{
		return StringTable.getInstance().getId(identifier);
	}
}
