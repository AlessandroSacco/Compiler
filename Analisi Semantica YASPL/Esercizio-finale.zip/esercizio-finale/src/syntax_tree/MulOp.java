package syntax_tree;

 

import xmlvisitor.Visitable;
import xmlvisitor.Visitor;

public class MulOp extends SimpleExpression implements Visitable{
	public String multiplyingOp;
	public SimpleExpression sExpr1, sExpr2;
	public MulOp(SimpleExpression sExpr1, String multiplyingOp, SimpleExpression sExpr2) {
		super();
		this.multiplyingOp = multiplyingOp;
		this.sExpr1 = sExpr1;
		this.sExpr2 = sExpr2;
	}
	@Override
	public Object accept(Visitor v) {
		return v.visit(this);
	}
	@Override
	public String toString()
	{
		if(sExpr1 instanceof AddOp)
			System.out.println("Is addop");
		
		return sExpr1.toString()+multiplyingOp+sExpr2.toString();
	}
}
