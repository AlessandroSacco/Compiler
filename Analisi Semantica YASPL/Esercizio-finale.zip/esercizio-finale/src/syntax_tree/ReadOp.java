package syntax_tree;
import java.util.ArrayList;

 

import xmlvisitor.Visitable;
import xmlvisitor.Visitor;

public class ReadOp extends Stat implements Visitable{

	public ArrayList<VarOp> vList;
	public ReadOp(ArrayList<VarOp> vList) {
		super();
		this.vList = vList;
	}
	@Override
	public Object accept(Visitor v) {
		return v.visit(this);
	}
}
