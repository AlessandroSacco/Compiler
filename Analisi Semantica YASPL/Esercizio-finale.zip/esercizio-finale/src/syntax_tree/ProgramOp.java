package syntax_tree;

 

import xmlvisitor.Visitable;
import xmlvisitor.Visitor;

public class ProgramOp extends Root implements Visitable{
	public int identifier;
	public BlockOp ref;
	
	public ProgramOp(int attribute, BlockOp ref)
	{
		this.identifier = attribute;
		this.ref = ref; 
	}
	@Override
	public Object accept(Visitor v) {
		return v.visit(this);
	}
}
