package syntax_tree;

 

import xmlvisitor.Visitable;
import xmlvisitor.Visitor;

public class IfThenElseOp extends Stat implements Visitable{
	public Expression expr;
	public Stat stat1,stat2;
	public IfThenElseOp(Expression expr, Stat stat1, Stat stat2) {
		super();
		this.expr = expr;
		this.stat1 = stat1;
		this.stat2 = stat2;
	}
	@Override
	public Object accept(Visitor v) {
		return v.visit(this);
	}
}
