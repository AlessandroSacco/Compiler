package syntax_tree;

 

import xmlvisitor.Visitor;

public class SimpleExpression extends Expression{

	public Object accept(Visitor xmlVisitor) {
		// TODO Auto-generated method stub
		return null;
	}

}
