package syntax_tree;

import semantic_analysis.Scope;

public class Root {
	Scope scope;

	public Scope getScope() {
		return scope;
	}

	public void setScope(Scope scope) {
		this.scope = scope;
	}
	
}
