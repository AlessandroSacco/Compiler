import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import cvisitor.CVisitor;
import semantic_analysis.ScopingVisitor;
import semantic_analysis.TypeCheckingVisitor;
import syntax_tree.ProgramOp;
import xmlvisitor.XMLVisitor;

public class Main {
	public static void main(String[] args) throws Exception {

		   File f = new File("C:\\Users\\Alessandro\\workspace\\esercizio-finale\\out.c ");
		   try {
		     ParserCup p = new ParserCup(new Lexer(new FileReader(args[0])));
		     ProgramOp r = (ProgramOp) p.parse().value;
		     ScopingVisitor scopingVisitor = new ScopingVisitor();
			 r.accept(scopingVisitor);
			 TypeCheckingVisitor typeCheckingVisitor = new TypeCheckingVisitor();
			 r.accept(typeCheckingVisitor);
			 CVisit(r,f);
			 System.out.println("Parsing --->Ok<---");
		     //System.out.println(r);
		    // XMLVisit(r,f);
		     //System.out.println("Albero Creato ----->OK xml<-----");
		     //p.parse();
		   } catch (Exception e) {
		    /* do cleanup here -- possibly rethrow e */
		     e.printStackTrace(); 
		      
		   }
		}	
		
		
/*		
	private static void XMLVisit(ProgramOp root, File file) throws ParserConfigurationException, FileNotFoundException, UnsupportedEncodingException, TransformerException
	{
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
		Document doc = docBuilder.newDocument();
		XMLVisitor visitor = new XMLVisitor(doc);
		doc.appendChild((Element)root.accept(visitor)); 
		OutputStream stream = new FileOutputStream(new File("./outputXML/"+file.getName()+"XML.xml"));
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer = tf.newTransformer();
		transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
		transformer.setOutputProperty(OutputKeys.METHOD, "xml");
		transformer.setOutputProperty(OutputKeys.INDENT, "yes");
		transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
		transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
		transformer.transform(new DOMSource(doc), 
				new StreamResult(new OutputStreamWriter(stream, "UTF-8")));
	}
*/	
	private static void CVisit(ProgramOp root, File file) throws FileNotFoundException
	{
		CVisitor visitorC = new CVisitor();
		String cCode = (String) root.accept(visitorC);
		//System.out.println(cCode);
		PrintWriter writer2 = new PrintWriter(new FileOutputStream(file));
		writer2.write(cCode);
		writer2.close();
	}

}
