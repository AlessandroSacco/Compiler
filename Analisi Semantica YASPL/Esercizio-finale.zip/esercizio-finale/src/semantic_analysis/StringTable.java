package semantic_analysis;

import java.util.ArrayList;

import java_cup.runtime.Symbol;

public class StringTable {
	private StringTable()
	{
		table = new ArrayList<String>();
	}
	public static StringTable getInstance()
	{
		return instance;
	}
	public Symbol installId(int type,int yyline, int yycolumn, String value)
	{
			for(int i=0; i<table.size(); i++)
				if(value.equals(table.get(i)))
					return new Symbol(type,yyline,yycolumn,i);
			table.add(value);
			return new Symbol(type,yyline,yycolumn,table.size()-1);
	}
	public String getId(int id)
	{
		return table.get(id);
	}
	private ArrayList<String> table;
	private static final StringTable instance = new StringTable();
}
