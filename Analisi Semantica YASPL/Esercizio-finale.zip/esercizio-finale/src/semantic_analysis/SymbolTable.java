package semantic_analysis;

import java.util.HashMap;
import java.util.Stack;

import semantic_analysis.SymTableKey.IdKind;
import syntax_tree.Type;

public final class SymbolTable {
	
	private SymbolTable()
	{
		HashMap<SymTableKey,Type> initialScope = new HashMap<>();
		actualScope = new Scope(initialScope,null);
		symbolTable = new Stack<>();
		symbolTable.push(actualScope);
	}



	
	public static SymbolTable getInstance()
	{
		return instance;
	}
	public void enterScope()
	{
		HashMap<SymTableKey,Type> newScope = new HashMap<>();
		actualScope = new Scope(newScope,actualScope);
		symbolTable.push(actualScope);
	}
	public void addId(int identifier,IdKind kind, Type type)
	{
		SymTableKey key = new SymTableKey(identifier,kind);
		actualScope.put(key, type);
	}
	public boolean probe(int identifier, IdKind kind)
	{
		//verifico se gia sta dichiarato nello scop attuale
		SymTableKey key = new SymTableKey(identifier,kind);
		return actualScope.get(key)!=null;
	}
	public void exitScope()
	{
		symbolTable.pop();
	}
	public Type lookup(int identifier, IdKind kind)
	{
		SymTableKey key = new SymTableKey(identifier,kind);
		int index = symbolTable.size()-1;
		Type toReturn = null;
		while(index!=-1)
		{
			toReturn = symbolTable.get(index).get(key);
			index--;
		}
		return toReturn;
	}
	public Scope getActualScope()		
	{
		return actualScope;
	}
	public void clear() {
		HashMap<SymTableKey,Type> initialScope = new HashMap<>();
		actualScope = new Scope(initialScope,null);
		symbolTable = new Stack<>();
		symbolTable.push(actualScope);
	}
	public Stack<Scope> symbolTable;
	private Scope actualScope;
	private static final SymbolTable instance = new SymbolTable();
	
}
