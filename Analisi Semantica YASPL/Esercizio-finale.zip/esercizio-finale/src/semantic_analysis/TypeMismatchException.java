package semantic_analysis;

public class TypeMismatchException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public TypeMismatchException(String msg)
	{
		super(msg);
	}

}
