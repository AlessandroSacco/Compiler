package semantic_analysis;

import java.util.HashMap;

import syntax_tree.Type;

public class Scope {
	public Scope(HashMap<SymTableKey, Type> scope, Scope father) {
		super();
		this.scope = scope;
		this.setFather(father);
	}
	public HashMap<SymTableKey, Type> getScope() {
		return scope;
	}
	public void setScope(HashMap<SymTableKey, Type> scope) {
		this.scope = scope;
	}
	public Type get(SymTableKey key)
	{
		return scope.get(key);
	}
	public void put(SymTableKey key, Type type)
	{
		scope.put(key, type);
	}
	public Scope getFather() {
		return father;
	}
	public void setFather(Scope father) {
		this.father = father;
	}
private HashMap<SymTableKey,Type> scope;
private Scope father;
}
