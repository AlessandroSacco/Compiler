package semantic_analysis;

import semantic_analysis.SymTableKey.IdKind;
import syntax_tree.*;
import xmlvisitor.Visitor;

public class TypeCheckingVisitor  implements Visitor {
	@Override
	//faccio il controllo sui tipi(intero o booleano)in caso di somma
	public Type visit(AddOp node) {
		Type first = (Type)node.sExpr1.accept(this);
		Type second = (Type)node.sExpr2.accept(this);
		if((first==Type.INTEGER && second==Type.INTEGER)||(first==Type.BOOLEAN && second == Type.BOOLEAN))
		{
			if(node.addingOp=="||")
				node.setType(Type.BOOLEAN);
			else
				node.setType(Type.INTEGER);
		}
		else
			throw new TypeMismatchException("You can't use this operator "+node.addingOp+" with a "+first+" and a"+second+"\n At instruction: "+node);
		return node.getType();
	}

	public Type visit(AssignOp node){
		//controllo semplicemente il tipo dell'id e di cosa vogliamo assegnarci
		Type first = (Type)node.identifier.accept(this);
		Type second = (Type)node.expr.accept(this);
		if(!first.equals(second))
			throw new TypeMismatchException("You can't assign a "+second+" to a "+first+" variable \n At instruction: "+node);
		return first;
	}
	public Type visit(BlockOp node){
		node.vdpRef.accept(this);
		node.pdpRef.accept(this);
		node.spRef.accept(this);
		return null;
	}
	public Type visit(CallOp node){
		return null;
	}
	public Type visit(CompStatOp node)
	{
		Type type = null;
		for(Stat s : node.sList)
		{
			type = (Type)s.accept(this);
		}
		return type;
	}
	public Type visit(ConstOp node)
	{
		return node.getType();
	}
	public Type visit(ExprOp node)
	{
		return (Type)node.expr.accept(this);
	}
	public Type visit(IfThenElseOp node)
	{
		Type type= (Type) node.expr.accept(this);
		if(type==Type.INTEGER || type==Type.BOOLEAN)
		{
		node.stat1.accept(this);
		node.stat2.accept(this);
		}
		else
			throw new TypeMismatchException("You are trying to evaluate an expression which is not INTEGER or BOOLEAN");
		return null;
	}
	public Type visit(IfThenOp node)
	{
		Type type= (Type) node.expr.accept(this);
		if(type==Type.INTEGER || type==Type.BOOLEAN)
			node.stat.accept(this);
		else
			throw new TypeMismatchException("You are trying to evaluate an expression which is not INTEGER or BOOLEAN");
		return null;
	}
	public Type visit(MulOp node) {
		Type first = (Type)node.sExpr1.accept(this);
		Type second = (Type)node.sExpr2.accept(this);
		if(first==Type.INTEGER && second==Type.INTEGER)
		{
			if(node.multiplyingOp=="&&")
				node.setType(Type.BOOLEAN);
			else
				node.setType(Type.INTEGER);
		}
		else if(first==Type.BOOLEAN && second == Type.BOOLEAN)
		{
			if(node.multiplyingOp=="&&")
				node.setType(Type.BOOLEAN);
			else
				node.setType(Type.INTEGER);
		}
		else
			throw new TypeMismatchException("You can't use this operator "+ node.multiplyingOp+ " with a(n) "+first+" and a(n) "+second+"\n At instruction "+node);
		return node.getType();
	}
	public Type visit(NotOp node)
	{
		Type type = (Type)node.expr.accept(this);
		if(type==Type.INTEGER || type==Type.BOOLEAN)
		{
			node.setType(Type.BOOLEAN);
			return node.getType();
		}
		else
			throw new TypeMismatchException("The Not operator requires, as argument, a boolean or an integer");
	}
	public Type visit(ProcDeclOp node)
	{
		node.sblock.accept(this);
		return null;
	}
	public Type visit(ProcDeclPartOp node)
	{
		for(ProcDeclOp s : node.pdList)
			s.accept(this);
		return null;
	}
	public Type visit(ProgramOp node)
	{
		node.ref.accept(this);
		return null;
	}
	public Type visit(ReadOp node)
	{
		for(VarOp s : node.vList)
		{
			s.accept(this);
		}
		return null;
	}
	public Type visit(RelationalOp node)
	{
		Type first = (Type)node.sExpr1.accept(this);
		Type second = (Type)node.sExpr2.accept(this);
		if((first==Type.INTEGER && second==Type.INTEGER)||(first==Type.BOOLEAN && second == Type.BOOLEAN))
			node.setType(Type.BOOLEAN);
		else
			throw new TypeMismatchException("You can't compare a "+first+" and a "+second+"\n At instruction "+node);
		return node.getType();
	}
	public Type visit(SimpleBlockOp node)
	{
		node.vdPart.accept(this);
		node.cStat.accept(this);
		return null;
	}
	public Type visit(SimpleExprOp node)
	{
		return node.getType();
	}
	public Type visit(UnaryMinusOp node)
	{
		Type type = (Type)node.sExpr.accept(this);
		if(type==Type.INTEGER || type==Type.BOOLEAN)
		{
			node.setType(Type.INTEGER);
			return node.getType();
		}
		else
			throw new TypeMismatchException("The UnaryMinus operator requires, as argument, a boolean or an integer");
	}
	public Type visit(VarDeclOp node)
	{
		for(VarOp s : node.vList)
		{
			s.accept(this);
		}
		return null;
	}
	public Type visit(VarDeclPartOp node)
	{
		for(VarDeclOp s : node.vdList)
		{
			s.accept(this);
		}
		return null;
	}
	public Type visit(VarOp node)
	{
		//lookup � un metodo di questa classe 
		Type type = lookup(node.identifier,IdKind.VAR,node.getScope());
		if(type!=null)
			return type;
		else
			throw new UndeclaredIdentifierException("Undeclared variable:"+StringTable.getInstance().getId(node.identifier));
	}
	public Type visit(WhileOp node)
	{
		Type type= (Type) node.expr.accept(this);
		if(type==Type.INTEGER || type==Type.BOOLEAN)
			node.stat.accept(this);
		else
			throw new TypeMismatchException("You are trying to evaluate an expression which is not INTEGER or BOOLEAN: "+node.expr);
		return null;
	}
	public Type visit(WriteOp node)
	{
		for(Expression e : node.eList)
		{
			e.accept(this);
		}
		return null;
	}

	@Override
	public Type visit(ProcCallOp node) {
		Type type = lookup(node.identifier, IdKind.PROCEDURE, node.getScope());
		if(type!=null)
			return type;
		else
			throw new UndeclaredIdentifierException("Undeclared procedure:"+StringTable.getInstance().getId(node.identifier));
	}
	
	private Type lookup(int identifier, IdKind kind, Scope scope)
	{
		SymTableKey key = new SymTableKey(identifier,kind);
		Type returned = scope.get(key);
		while(returned == null)
		{
			//lo cerco nel padre
			scope = scope.getFather();
			if(scope==null)
				return null;
			returned = scope.get(key);
		}
		return returned;
	}
	SymbolTable table = SymbolTable.getInstance();
}