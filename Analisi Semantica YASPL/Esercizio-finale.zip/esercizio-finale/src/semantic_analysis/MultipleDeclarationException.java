package semantic_analysis;

public class MultipleDeclarationException extends RuntimeException{

	public MultipleDeclarationException(String string) {
		// TODO Auto-generated constructor stub
		super(string);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
