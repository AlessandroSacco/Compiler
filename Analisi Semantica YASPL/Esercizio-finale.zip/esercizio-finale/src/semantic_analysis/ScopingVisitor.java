package semantic_analysis;

import semantic_analysis.SymTableKey.IdKind;
import syntax_tree.AddOp;
import syntax_tree.AssignOp;
import syntax_tree.BlockOp;
import syntax_tree.CallOp;
import syntax_tree.CompStatOp;
import syntax_tree.ConstOp;
import syntax_tree.ExprOp;
import syntax_tree.Expression;
import syntax_tree.IfThenElseOp;
import syntax_tree.IfThenOp;
import syntax_tree.MulOp;
import syntax_tree.NotOp;
import syntax_tree.ProcCallOp;
import syntax_tree.ProcDeclOp;
import syntax_tree.ProcDeclPartOp;
import syntax_tree.ProgramOp;
import syntax_tree.ReadOp;
import syntax_tree.RelationalOp;
import syntax_tree.SimpleBlockOp;
import syntax_tree.SimpleExprOp;
import syntax_tree.Stat;
import syntax_tree.Type;
import syntax_tree.UnaryMinusOp;
import syntax_tree.VarDeclOp;
import syntax_tree.VarDeclPartOp;
import syntax_tree.VarOp;
import syntax_tree.WhileOp;
import syntax_tree.WriteOp;
import xmlvisitor.Visitor;

public class ScopingVisitor implements Visitor {
	@Override
	public Void visit(AddOp node) {
		node.sExpr1.accept(this);
		node.sExpr2.accept(this);
		//lego lo scop al nodo
		node.setScope(table.getActualScope());  return null;
	}

	public Void visit(AssignOp node){
		node.identifier.accept(this);
		node.expr.accept(this);
		node.setScope(table.getActualScope());  return null;
	}
	public Void visit(BlockOp node){
		node.vdpRef.accept(this);
		node.pdpRef.accept(this);
		node.spRef.accept(this);
		node.setScope(table.getActualScope());  return null;
	}
	public Void visit(CallOp node){
		node.setScope(table.getActualScope());  return null;
	}
	public Void visit(CompStatOp node)
	{
		for(Stat s : node.sList)
		{
			s.accept(this);
		}
		node.setScope(table.getActualScope());  return null;
	}
	public Void visit(ConstOp node)
	{
		node.setScope(table.getActualScope());  return null;
	}
	public Void visit(ExprOp node)
	{
		node.expr.accept(this);
		node.setScope(table.getActualScope());  return null;
	}
	public Void visit(IfThenElseOp node)
	{
		node.expr.accept(this);
		node.stat1.accept(this);
		node.stat2.accept(this);
		node.setScope(table.getActualScope());  return null;
	}
	public Void visit(IfThenOp node)
	{
		node.expr.accept(this);
		node.stat.accept(this);
		node.setScope(table.getActualScope());  return null;
	}
	public Void visit(MulOp node) {
		node.sExpr1.accept(this);
		node.sExpr2.accept(this);
		node.setScope(table.getActualScope());  return null;
	}
	public Void visit(NotOp node)
	{
		node.expr.accept(this);
		node.setScope(table.getActualScope());  return null;
	}
	public Void visit(ProcDeclOp node)
	{
		//vedo se la procedura (node) � gia stata dichiarata(con probe)
		boolean probe = table.probe(node.identifier, IdKind.PROCEDURE);
		if(probe==false)
			//creo lo scope 
			table.addId(node.identifier, IdKind.PROCEDURE, Type.VOID);
		else
			throw new MultipleDeclarationException("Multiple declared procedure");
		//lo inserisco al top dello stack
		table.enterScope();
		node.sblock.accept(this);
		node.setScope(table.getActualScope()); 
		table.exitScope(); 
		return null;
	}
	public Void visit(ProcDeclPartOp node)
	{
		for(ProcDeclOp s : node.pdList)
			s.accept(this);
		node.setScope(table.getActualScope());  
		return null;
	}
	public Void visit(ProgramOp node)
	{
		table = SymbolTable.getInstance();
		table.clear();
		node.setScope(table.getActualScope()); 
		node.ref.accept(this);
		//una volta visitati tutti i figli posso eliminarlo dallo stack
		table.exitScope(); 
		return null;
	}
	public Void visit(ReadOp node)
	{
		for(VarOp s : node.vList)
		{
			s.accept(this);
		}
		node.setScope(table.getActualScope());  return null;
	}
	public Void visit(RelationalOp node)
	{
		node.sExpr1.accept(this);
		node.sExpr2.accept(this);
		node.setScope(table.getActualScope());  return null;
	}
	public Void visit(SimpleBlockOp node)
	{
		node.vdPart.accept(this);
		node.cStat.accept(this);
		node.setScope(table.getActualScope());  return null;
	}
	public Void visit(SimpleExprOp node)
	{
		node.sExpression.accept(this);
		node.setScope(table.getActualScope());  return null;
	}
	public Void visit(UnaryMinusOp node)
	{
		node.sExpr.accept(this);
		node.setScope(table.getActualScope());  return null;
	}
	public Void visit(VarDeclOp node)
	{
		for(VarOp s : node.vList)
		{
			boolean probe = table.probe(s.identifier, IdKind.VAR);
			if(probe)
				throw new MultipleDeclarationException("Multiple declared variable");
			else
				if(node.type == "integer")
					table.addId(s.identifier,IdKind.VAR, Type.INTEGER);
				else
					table.addId(s.identifier,IdKind.VAR, Type.BOOLEAN);
			s.accept(this);
		}
		node.setScope(table.getActualScope()); 
		return null;
	}
	public Void visit(VarDeclPartOp node)
	{
		for(VarDeclOp s : node.vdList)
		{
			s.accept(this);
		}
		node.setScope(table.getActualScope());  
		return null;
	}
	public Void visit(VarOp node)
	{
		node.setScope(table.getActualScope()); 
		return null;
	}
	public Void visit(WhileOp node)
	{
		node.expr.accept(this);
		node.stat.accept(this);
		node.setScope(table.getActualScope());  return null;
	}
	public Void visit(WriteOp node)
	{
		for(Expression e : node.eList)
		{
			e.accept(this);
		}
		node.setScope(table.getActualScope());  return null;
	}

	@Override
	public Void visit(ProcCallOp node) {
		node.setScope(table.getActualScope());  return null;
	}
	SymbolTable table;
	StringTable stringTable;
}
