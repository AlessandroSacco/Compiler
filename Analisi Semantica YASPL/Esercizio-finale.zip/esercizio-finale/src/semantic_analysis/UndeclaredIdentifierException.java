package semantic_analysis;

public class UndeclaredIdentifierException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public UndeclaredIdentifierException(String msg)
	{
		super(msg);
	}

}
