package semantic_analysis;

public class SymTableKey {
	public SymTableKey(int identifier, IdKind kind) {
		super();
		this.identifier = identifier;
		this.kind = kind;
	}
	public enum IdKind{
		VAR,
		PROCEDURE
	}

	public IdKind getKind() {
		return kind;
	}
	public int getId()
	{
		return identifier;
	}
	@Override
	public int hashCode()
	{
	    return identifier;
	}
	public boolean equals(Object o)
	{
	    return this.identifier==(((SymTableKey)o).identifier)&&this.kind==((SymTableKey)o).kind;
	}
	private int identifier;
	private IdKind kind;
}
