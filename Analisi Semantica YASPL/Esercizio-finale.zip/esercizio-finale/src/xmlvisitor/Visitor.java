package xmlvisitor;

import syntax_tree.*;

public interface Visitor {
	
	Object visit(AddOp node);
	Object visit(AssignOp node);
	Object visit(BlockOp node);
	Object visit(CallOp node);
	Object visit(CompStatOp node);
	Object visit(ConstOp node);
	Object visit(ExprOp node);
	Object visit(IfThenElseOp node);
	Object visit(IfThenOp node);
	Object visit(MulOp node);
	Object visit(NotOp node);
	Object visit(ProcDeclOp node);
	Object visit(ProcDeclPartOp node);
	Object visit(ProgramOp node);
	Object visit(ReadOp node);
	Object visit(RelationalOp node);
	Object visit(SimpleBlockOp node);
	Object visit(SimpleExprOp node);
	Object visit(UnaryMinusOp node);
	Object visit(VarDeclOp node);
	Object visit(VarDeclPartOp node);
	Object visit(VarOp node);
	Object visit(WhileOp node);
	Object visit(WriteOp node);
	Object visit(ProcCallOp procCallOp);
}
