package xmlvisitor;

 

public interface Visitable {

	public Object accept(Visitor v);

}
