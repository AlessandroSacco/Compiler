package cvisitor;

import semantic_analysis.StringTable;
import syntax_tree.*;
import xmlvisitor.Visitor;

public class CVisitor implements Visitor {

	@Override
	public String visit(AddOp node) {
		return node.sExpr1.accept(this)+ node.addingOp + node.sExpr2.accept(this);
	}

	public String visit(AssignOp node){
		return "\n"+(String)node.identifier.accept(this)+"="+(String)node.expr.accept(this)+";";
	}
	public String visit(BlockOp node){
		return (String) node.vdpRef.accept(this)+(String)node.pdpRef.accept(this)+(String)node.spRef.accept(this);
	}
	public String visit(CallOp node){
		return node.identifier+"();";
	}
	public String visit(CompStatOp node)
	{
		String toReturn = "";
		for(Stat s : node.sList)
		{
			toReturn+=(String)s.accept(this);
		}
		return toReturn;
	}
	public String visit(ConstOp node)
	{
		return node.constant;
	}
	public String visit(ExprOp node)
	{
		return (String)node.expr.accept(this);
	}
	public String visit(IfThenElseOp node)
	{
		String toReturn = "";
		toReturn+= "\nif("+(String)node.expr.accept(this)+")";
		toReturn+="{ \t "+(String)node.stat1.accept(this)+"\n}\nelse { \t "+(String)node.stat2.accept(this)+"\n}";
		return toReturn;
	}
	public String visit(IfThenOp node)
	{
		String toReturn = "";
		toReturn+= "\nif("+(String)node.expr.accept(this)+")";
		toReturn+="{ \t"+(String)node.stat.accept(this)+"}";
		return toReturn;
	}
	public String visit(MulOp node) {
		// TODO Auto-generated method stub
		return node.sExpr1.accept(this)+ node.multiplyingOp + node.sExpr2.accept(this);

	}
	public String visit(NotOp node)
	{
		return "!"+node.expr.accept(this);
	}
	public String visit(ProcDeclOp node)
	{
		String toReturn = "\nvoid "+StringTable.getInstance().getId(node.identifier)+"()\n{";
		toReturn += node.sblock.accept(this)+"\n}";
		return toReturn;
	}
	public String visit(ProcDeclPartOp node)
	{
		String toReturn = "\t";
		for(ProcDeclOp s : node.pdList)
			toReturn+= (String)s.accept(this);
		return toReturn;
	}
	public String visit(ProgramOp node)
	{
		String toReturn= "#include <stdio.h> \nint main() \n{";
		toReturn += (String)node.ref.accept(this)+"\nreturn 0; \n}";
		return toReturn;
	}
	public String visit(ReadOp node)
	{
		String toReturn=  "\nscanf(\"";
		String toReturn2 = "";
		for(VarOp s : node.vList)
		{
			toReturn += "%d ";
			toReturn2 +="&"+s.accept(this)+",";
		}
		//System.out.println(toReturn2);
		toReturn2 = toReturn2.substring(0,toReturn2.length()-1)+");";
		//System.out.println(toReturn2);
		return toReturn.substring(0,toReturn.length()-1)+"\","+toReturn2;
	}
	public String visit(RelationalOp node)
	{
		return node.sExpr1.accept(this)+node.relOp+node.sExpr2.accept(this);
	}
	public String visit(SimpleBlockOp node)
	{
		return (String)node.vdPart.accept(this)+(String)node.cStat.accept(this);
	}
	public String visit(SimpleExprOp node)
	{
		return (String)node.sExpression.accept(this);
	}
	public String visit(UnaryMinusOp node)
	{
		return "-"+(String)node.sExpr.accept(this);
	}
	public String visit(VarDeclOp node)
	{
		String toReturn = "\nint ";
		for(VarOp s : node.vList)
			toReturn += (String)s.accept(this)+",";
		String sub = toReturn.substring(0, toReturn.length()-1);
		sub+=";";
		return sub;
	}
	public String visit(VarDeclPartOp node)
	{
		String toReturn ="";
		for(VarDeclOp s : node.vdList)
		{
			toReturn+=(String)s.accept(this);
		}
		return toReturn;
	}
	public String visit(VarOp node)
	{
		return StringTable.getInstance().getId(node.identifier);
	}
	public String visit(WhileOp node)
	{
		return "\nwhile("+(String)node.expr.accept(this)+") { \t "+node.stat.accept(this)+"\n}";
	}
	public String visit(WriteOp node)
	{
		String toReturn = "\nprintf(\"";
		String toReturn2 = "\",";
		for(Expression e : node.eList)
		{
			Type t = e.getType();
			if(t!=null && t.equals(Type.STRING))
			{
				toReturn+=e.accept(this).toString().replace("\n", "\\n");
			}
			else
			{
				toReturn+="%d ";
				toReturn2+=(String)e.accept(this)+",";
			}
		}
		return toReturn+toReturn2.substring(0, toReturn2.length()-1)+");";
	}

	@Override
	public String visit(ProcCallOp node) {
		return "\n"+StringTable.getInstance().getId(node.identifier)+"();";
	}

}
