package tree;

import ese4.Visitable;
import ese4.Visitor;

public class ExprOp extends SimpleExpression implements Visitable {
	public ExprOp(Expression e){
		super();
		this.e=e;
	}
	@Override
	public Object accept(Visitor v) {
		// TODO Auto-generated method stub
		return v.visit(this);
	}
public Expression e;
}
