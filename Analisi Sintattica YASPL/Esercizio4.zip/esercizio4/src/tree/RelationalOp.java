package tree;

import ese4.Visitable;
import ese4.Visitor;

public class RelationalOp extends Expression implements Visitable {
	public RelationalOp(SimpleExpression s1,String relop,SimpleExpression s2){
		super();
		this.relop=relop;
		this.s1=s1;
		this.s2=s2;
	}
	
public Object accept(Visitor v) {
// TODO Auto-generated method stub
		return v.visit(this);
	}
	
	
	
public String relop;
public SimpleExpression s1;
public SimpleExpression s2;
}
