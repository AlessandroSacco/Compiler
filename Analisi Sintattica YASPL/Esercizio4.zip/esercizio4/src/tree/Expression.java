package tree;

import ese4.Visitor;

public class Expression {
	public Type getType() {
		return type;
	}
	public void setType(Type type) {
		this.type = type;
	}
	public Object accept(Visitor v) {
		// TODO Auto-generated method stub
		return null;
	}
	Type type;

}
