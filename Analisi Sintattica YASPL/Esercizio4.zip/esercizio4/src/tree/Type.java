package tree;

public enum Type{
	BOOLEAN,INTEGER,STRING,VOID,CHARACTER;
}