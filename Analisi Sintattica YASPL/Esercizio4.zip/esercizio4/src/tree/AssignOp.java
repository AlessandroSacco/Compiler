package tree;

import ese4.Visitable;
import ese4.Visitor;

public class AssignOp extends Stat implements Visitable{
	public AssignOp(VarOp op,Expression e){
		super();
		this.op=op;
		this.e=e;
		
	}
	
public Object accept(Visitor v) {
		return v.visit(this);
}

public String toString()
{
	return op.toString()+":="+e.toString();
}	
	
	
public VarOp op;
public Expression e;
	
	

}
