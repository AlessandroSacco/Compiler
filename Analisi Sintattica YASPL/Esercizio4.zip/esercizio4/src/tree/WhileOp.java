package tree;

import ese4.Visitable;
import ese4.Visitor;

public class WhileOp extends Stat implements Visitable{
	public WhileOp(Expression e,Stat s) {
		// TODO Auto-generated constructor stub
		super();
		this.e=e;
		this.s=s;
	}

	@Override
	public Object accept(Visitor v) {
		// TODO Auto-generated method stub
		return v.visit(this);
	}
public Expression e;
public Stat s;
}
