package tree;

import java.util.ArrayList;

import ese4.Visitable;
import ese4.Visitor;

public class ReadOp extends Stat implements Visitable {
	public ReadOp(ArrayList<VarOp> vList){
		super();
		this.vList=vList;
	}

	@Override
	public Object accept(Visitor v) {
		// TODO Auto-generated method stub
		return v.visit(this);
	}
	
public ArrayList<VarOp> vList;	
}
