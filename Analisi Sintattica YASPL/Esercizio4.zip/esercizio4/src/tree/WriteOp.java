package tree;

import java.util.ArrayList;

import ese4.Visitable;
import ese4.Visitor;

public class WriteOp extends Stat implements Visitable{
	public WriteOp(ArrayList<Expression> eList) {
		// TODO Auto-generated constructor stub
		super();
		this.eList=eList;
	}
	
	
	@Override
	public Object accept(Visitor v) {
		// TODO Auto-generated method stub
		return v.visit(this);
	}
	
public ArrayList<Expression> eList;

}
