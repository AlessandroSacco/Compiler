package tree;

import java.util.ArrayList;

import ese4.Visitable;
import ese4.Visitor;

public class ProDeclOp implements Visitable{
	public ProDeclOp(String id, SimpleBlockOp sb) {
		// TODO Auto-generated constructor stub
		super();
		this.id=id;
		this.sb=sb;
	}
	@Override
	public Object accept(Visitor v) {
		//System.out.println(id+","+sb);
		return v.visit(this);
	}
	
public String id;
public SimpleBlockOp sb;
}
