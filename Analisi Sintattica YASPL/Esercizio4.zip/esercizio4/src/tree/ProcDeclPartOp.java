package tree;

import java.util.ArrayList;

import ese4.Visitable;
import ese4.Visitor;

public class ProcDeclPartOp implements Visitable{
	 public ProcDeclPartOp(ArrayList<ProDeclOp> pdList) {
		 super();
		 this.pdList=pdList;
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public Object accept(Visitor v) {
		// TODO Auto-generated method stub
		return v.visit(this);
	}
	
	public void add(ProDeclOp el) {
		// TODO Auto-generated method stub
		ArrayList<ProDeclOp> newList = new ArrayList<ProDeclOp>();
		newList.add(el);
		newList.addAll(pdList);
		pdList = newList;
	}

public ArrayList<ProDeclOp> pdList;
	

}
