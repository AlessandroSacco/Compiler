package tree;

import ese4.Visitable;
import ese4.Visitor;

public class UnaryMinusOp extends SimpleExpression implements Visitable {
	public UnaryMinusOp(SimpleExpression se) {
		// TODO Auto-generated constructor stub
		super();
		this.se=se;
	}
	@Override
	public Object accept(Visitor v) {
		// TODO Auto-generated method stub
		return v.visit(this);
	}

	public String toString()
	{
		return "-"+se.toString();
	}
	
public SimpleExpression se;
	
}
