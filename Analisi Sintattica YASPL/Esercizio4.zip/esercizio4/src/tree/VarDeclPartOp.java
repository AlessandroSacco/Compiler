package tree;

import java.util.ArrayList;

import ese4.Visitable;
import ese4.Visitor;

public class VarDeclPartOp implements Visitable {
	public VarDeclPartOp (ArrayList<VarDeclOp> vdList){
		super();
		this.vdList=vdList;
	}
@Override
public Object accept(Visitor v) {
	// TODO Auto-generated method stub
	return v.visit(this);
}

public void add(VarDeclOp vDecl) {
	// TODO Auto-generated method stub
	vdList.add(vDecl);
}

public ArrayList<VarDeclOp> vdList;

}
