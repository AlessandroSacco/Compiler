package tree;

import ese4.Visitable;
import ese4.Visitor;

public class SimpleBlockOp implements Visitable{
	public SimpleBlockOp(VarDeclPartOp vdp, CompStatOp cs) {
		// TODO Auto-generated constructor stub
		super();
		this.vdp=vdp;
		this.cs=cs;
	}
	@Override
	public Object accept(Visitor v) {
		// TODO Auto-generated method stub
		return v.visit(this);
	}
	
public VarDeclPartOp vdp;
public CompStatOp cs;
}
