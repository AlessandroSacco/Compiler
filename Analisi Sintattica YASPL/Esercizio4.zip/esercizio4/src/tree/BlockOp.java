package tree;

import ese4.Visitable;
import ese4.Visitor;

public class BlockOp implements Visitable{
		public BlockOp(VarDeclPartOp ref1, ProcDeclPartOp ref2,CompStatOp ref3)
		{
			this.vdpRef=ref1;
			this.pdpRef=ref2;
			this.spRef=ref3;
		}
		@Override
		public Object accept(Visitor v) {
			return v.visit(this);
		}
		
public VarDeclPartOp vdpRef;
public ProcDeclPartOp pdpRef;
public CompStatOp spRef;

}