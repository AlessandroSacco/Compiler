package tree;

import ese4.Visitable;
import ese4.Visitor;

public class NotOp extends SimpleExpression implements Visitable {
	public NotOp(Expression e) {
		// TODO Auto-generated constructor stub
		super();
		this.e=e;
	}
	@Override
	public Object accept(Visitor v) {
		// TODO Auto-generated method stub
		return v.visit(this);
	}
	public String toString()
	{
		return e.toString();
	}
	
	
	
public Expression e;

}
