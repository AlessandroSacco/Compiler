package tree;
import ese4.*;

public class ProgramOp implements Visitable{
		public ProgramOp(String attribute, BlockOp ref)
		{
			this.id = attribute;
			this.ref = ref; 
		}
		@Override
		public Object accept(Visitor v) {
			return v.visit(this);
		}
		
public String id;
public BlockOp ref;

}