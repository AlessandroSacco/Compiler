package tree;

import ese4.Visitable;
import ese4.Visitor;

public class MulOp extends SimpleExpression implements Visitable{
	public MulOp(SimpleExpression s1,String mop,SimpleExpression s2) {
		// TODO Auto-generated constructor stub
		super();
		this.mop=mop;
		this.s1=s1;
		this.s2=s2;
		
	}
	@Override
	public Object accept(Visitor v) {
		// TODO Auto-generated method stub
		return v.visit(this);
	}
	
public String mop;	
public SimpleExpression s1;
public SimpleExpression s2;

}
