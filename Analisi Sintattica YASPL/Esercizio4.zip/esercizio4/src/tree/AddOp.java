package tree;

import ese4.Visitable;
import ese4.Visitor;

public class AddOp extends SimpleExpression implements Visitable{
	public AddOp(SimpleExpression s1,String aop,SimpleExpression s2){
		super();
		this.aop=aop;
		this.s1=s1;
		this.s2=s2;
	}
	@Override
	public Object accept(Visitor v) {
		// TODO Auto-generated method stub
		return v.visit(this);
	}
public String aop; 
public SimpleExpression s1;
public SimpleExpression s2;
}
