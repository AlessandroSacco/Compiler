package tree;

import java.util.ArrayList;

import ese4.Visitable;
import ese4.Visitor;

public class CompStatOp implements Visitable {
	public CompStatOp(ArrayList<Stat> sList) {
		// TODO Auto-generated constructor stub
		super();
		this.sList=sList;
		
	}

	@Override
	public Object accept(Visitor v) {
		// TODO Auto-generated method stub
		return v.visit(this);
	}
public ArrayList<Stat> sList;
}
