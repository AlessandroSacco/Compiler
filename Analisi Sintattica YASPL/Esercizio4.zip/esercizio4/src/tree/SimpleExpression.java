package tree;

import ese4.Visitable;
import ese4.Visitor;

public class SimpleExpression extends Expression implements Visitable {
	public SimpleExpression(){super();}

	@Override
	public Object accept(Visitor v) {
		return null;
	}
}
