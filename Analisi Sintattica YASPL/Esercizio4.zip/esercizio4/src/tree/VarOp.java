package tree;

import ese4.Visitable;
import ese4.Visitor;

public class VarOp extends SimpleExpression implements Visitable{
	public VarOp(String id) {
		// TODO Auto-generated constructor stub
		super();
		this.id=id;
	}
	
	
public Object accept(Visitor v) {
		return v.visit(this);
}

public String id;

}
