package tree;

import ese4.Visitable;
import ese4.Visitor;

public class ProcCallOp extends Stat implements Visitable {
	public ProcCallOp(String id) {
		// TODO Auto-generated constructor stub
		super();
		this.id=id;
	}
	@Override
	public Object accept(Visitor v) {
		// TODO Auto-generated method stub
		return v.visit(this);
	}
public String id;
}
