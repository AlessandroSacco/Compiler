package tree;

import ese4.Visitable;
import ese4.Visitor;

public class SimpleExprOp extends Expression implements Visitable {
	public SimpleExprOp(SimpleExpression se){
		super();
		this.se=se;
	}

	@Override
	public Object accept(Visitor v) {
		// TODO Auto-generated method stub
		return v.visit(this);
	}
	public SimpleExpression se;
}
