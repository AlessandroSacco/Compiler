package tree;

import ese4.Visitable;
import ese4.Visitor;

public class Stat implements Visitable {
	public Stat(){	
	}
	
	public Object accept(Visitor v) {
		return null;
	}

}
