package tree;

import java.util.ArrayList;

import ese4.Visitable;
import ese4.Visitor;

public class VarDeclOp implements Visitable {
	public VarDeclOp(String type,ArrayList<VarOp> vList){
		this.type=type;
		this.vList=vList;
	}

	@Override
	public Object accept(Visitor v) {
		// TODO Auto-generated method stub
		return v.visit(this);
	}
	
	public void add(VarOp v)
	{
		vList.add(v);
	}
	
	
	
public String type;
public ArrayList<VarOp> vList;

}
