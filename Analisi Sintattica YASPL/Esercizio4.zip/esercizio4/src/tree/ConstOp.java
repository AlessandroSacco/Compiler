package tree;

import ese4.Visitable;
import ese4.Visitor;

public class ConstOp extends SimpleExpression implements Visitable {
	public ConstOp(String cons,Type t) {
	// TODO Auto-generated constructor stub
		super();
		this.cons=cons;
		this.t=t;
	}
	
	public Type getType() {
		return t;
	}
	public void setType(Type type) {
		this.t = type;
	}	
	
	public Object accept(Visitor v) {
		// TODO Auto-generated method stub
		return v.visit(this);
	}
	
	
public String cons;
public Type t;
	

}
