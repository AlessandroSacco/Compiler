package ese4;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class TreeNode implements Iterable<TreeNode> {
	
	public TreeNode(Object data) {
		this.data=data.toString();
		//this.data = (String)data;
	    this.children = new LinkedList<TreeNode>();
	    this.attr=new ArrayList<String>();
	}
	//inserisco i figli con annessi attributi
	public void addChild(TreeNode childNode, Object attList) {
		childNode.parent = this;
	    this.children.add(childNode);
	    childNode.addAttr(((String)attList));
	}
	//chiamato da addchild per inserire gli attributi come stringa
	private void addAttr(String attList){
		if(attList != null)
			//for(String a: attList)
			this.attr.add(attList);
	}
	
	public ArrayList<String> getAttr(){
		return this.attr;
	}

	public Iterator<TreeNode> iterator() {
		return null;
	}
	//formattazione e stampa di Value
	public String printTreeNode(){
		String toRet = "Root:\n\tdata: " + data + "\tattr: " + attr.toString() + "\nChildren:\n\t";
		if(parent != null)
			toRet += "parent: " + parent;
		for(TreeNode c: children){
			if(c.parent != null)
				toRet += "parent: " + c.parent.data + "\t";
			
			toRet += "data: " + c.data + "\tattr: " + c.attr.toString() + "\n\t";
		}
		
		return toRet;
	}


String data;
ArrayList<String> attr;
TreeNode parent;
List<TreeNode> children;
}
