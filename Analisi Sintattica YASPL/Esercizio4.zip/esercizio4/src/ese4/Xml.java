package ese4;
import tree.*;

import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class Xml implements Visitor {
	private Document doc;
	public Xml(Document doc) throws ParserConfigurationException{
		this.doc = doc;
	}
	
	@Override
	public Element visit(AddOp node) {
		// TODO Auto-generated method stub
		Element eNode = doc.createElement("AddOp");
		Element addOp = doc.createElement("Adding_Op");
		addOp.setAttribute("attr", node.aop);
		eNode.appendChild(addOp);
		eNode.appendChild((Element)node.s1.accept(this));
		eNode.appendChild((Element)node.s2.accept(this));
		return eNode;
	}
	public Element visit(AssignOp node){
		Element eNode = doc.createElement("AssignOp");
		eNode.appendChild((Element)node.op.accept(this));
		eNode.appendChild((Element)node.e.accept(this));
		return eNode;
	}
	public Element visit(BlockOp node){
		Element eNode = doc.createElement("BlockOp");
		eNode.appendChild((Element)node.vdpRef.accept(this));
		eNode.appendChild((Element)node.pdpRef.accept(this));
		eNode.appendChild((Element)node.spRef.accept(this));
		
		return eNode;
	}
	public Element visit(CallOp node){
		Element eNode = doc.createElement("CallOp");
		Element id = doc.createElement("ID");
		Attr attr = doc.createAttribute("attr");
		attr.setValue(node.id);
		eNode.appendChild(id);
		return eNode;
	}
	public Element visit(CompStatOp node)
	{
		Element eNode = doc.createElement("CompStatOp");
		for(Stat s : node.sList)
		{
			eNode.appendChild((Element)s.accept(this));
		}
		return eNode;
	}
	public Element visit(ConstOp node)
	{
		Element eNode = doc.createElement("ConstOp");
		Element constant = doc.createElement("CONSTANT");
		constant.setAttribute("attr", node.cons);
		eNode.appendChild(constant);
		return eNode;
	}
	public Element visit(ExprOp node)
	{
		Element eNode = doc.createElement("ExprOp");
		eNode.appendChild((Element)node.e.accept(this));
		return eNode;
	}
	public Element visit(IfThenElseOp node)
	{
		Element eNode = doc.createElement("IfThenElseOp");
		eNode.appendChild((Element)node.e.accept(this));
		eNode.appendChild((Element)node.s1.accept(this));
		eNode.appendChild((Element)node.s2.accept(this));
		return eNode;
	}
	public Element visit(IfThenOp node)
	{
		Element eNode = doc.createElement("IfThenOp");
		eNode.appendChild((Element)node.e.accept(this));
		eNode.appendChild((Element)node.s.accept(this));
		return eNode;
	}
	public Element visit(MulOp node) {
		// TODO Auto-generated method stub
		Element eNode = doc.createElement("MulOp");
		Element mulOp = doc.createElement("Multiplying_Op");
		mulOp.setAttribute("attr", node.mop);
		eNode.appendChild(mulOp);
		eNode.appendChild((Element)node.s1.accept(this));
		eNode.appendChild((Element)node.s2.accept(this));
		return eNode;
	}
	public Element visit(NotOp node)
	{
		Element eNode = doc.createElement("NotOp");
		eNode.appendChild((Element)node.e.accept(this));
		return eNode;
	}
	public Element visit(ProDeclOp node)
	{
		Element eNode = doc.createElement("ProcDeclOp");
		Element id = doc.createElement("ID");
		id.setAttribute("attr",node.id);
		//System.out.println(node.id);
		eNode.appendChild(id);
		eNode.appendChild((Element)node.sb.accept(this));
		//System.out.println("ciao");
		//System.out.println(eNode.getParentNode().getNodeName());
		return eNode;
	}
	public Element visit(ProcDeclPartOp node)
	{
		Element eNode = doc.createElement("ProcDeclPartOp");
		for(ProDeclOp s : node.pdList)
			//System.out.println(node.pdList.get(0).id);
			eNode.appendChild((Element)s.accept(this));
		return eNode;
	}
	public Element visit(ProgramOp node)
	{
		Element eNode = doc.createElement("ProgramOp");
		eNode.setAttribute("ID", node.id);
		eNode.appendChild((Element)node.ref.accept(this));
		return eNode;
	}
	public Element visit(ReadOp node)
	{
		Element eNode = doc.createElement("ReadOp");
		for(VarOp s : node.vList)
			eNode.appendChild((Element)s.accept(this));
		return eNode;
	}
	public Element visit(RelationalOp node)
	{
		Element eNode = doc.createElement("RelationalOp");
		Element relOp = doc.createElement("Relational_Op");
		relOp.setAttribute("attr", node.relop);
		eNode.appendChild(relOp);
		eNode.appendChild((Element)node.s1.accept(this));
		eNode.appendChild((Element)node.s2.accept(this));
		return eNode;
	}
	public Element visit(SimpleBlockOp node)
	{
		Element eNode = doc.createElement("SimbleBlockOp");
		eNode.appendChild((Element)node.vdp.accept(this));
		eNode.appendChild((Element)node.cs.accept(this));
		return eNode;
	}
	public Element visit(SimpleExprOp node)
	{
		Element eNode = doc.createElement("SimpleExprOp");
		eNode.appendChild((Element)node.se.accept(this));
		return eNode;
	}
	public Element visit(UnaryMinusOp node)
	{
		Element eNode = doc.createElement("UnaryMinusOp");
		eNode.appendChild((Element)node.se.accept(this));
		return eNode;
	}
	public Element visit(VarDeclOp node)
	{
		Element eNode = doc.createElement("VarDeclOp");
		eNode.setAttribute("type", node.type);
		for(VarOp s : node.vList)
			eNode.appendChild((Element)s.accept(this));
		return eNode;
	}
	public Element visit(VarDeclPartOp node)
	{
		Element eNode = doc.createElement("VarDeclPartOp");
		for(VarDeclOp s : node.vdList)
		{
			eNode.appendChild((Element)s.accept(this));
		}
		return eNode;
	}
	public Element visit(VarOp node)
	{
		Element eNode = doc.createElement("VarOp");
		eNode.setAttribute("id", node.id);
		return eNode;
	}
	public Element visit(WhileOp node)
	{
		Element eNode = doc.createElement("WhileOp");
		eNode.appendChild((Element)node.e.accept(this));
		eNode.appendChild((Element)node.s.accept(this));
		return eNode;
	}
	public Element visit(WriteOp node)
	{
		Element eNode = doc.createElement("WriteOp");
		for(Expression e : node.eList)
			eNode.appendChild((Element)e.accept(this));
		return eNode;
	}

	@Override
	public Element visit(ProcCallOp node) {
		Element eNode = doc.createElement("ProcCallOp");
		eNode.setAttribute("id",node.id);
		return eNode;
	}
}
