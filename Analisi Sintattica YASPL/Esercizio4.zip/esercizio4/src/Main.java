
import java.io.*;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;


import ese4.Xml;
import tree.ProgramOp;
public class Main {
	static public void main(String argv[]) throws IOException {    
	   /* Start the parser */
		/*//Vedere se la tabella dei simboli funziona
		Lexer l=new Lexer(new FileReader(argv[0]));
		l.next_token();
		for(int i=0;i<100;i++){
		System.out.println(l.yytext());
		l.next_token();
		}
		HashMap<Integer, String> app;
		app=l.stampH();
		System.out.println(app.entrySet());*/
		
		File f = new File("C:\\Users\\Alessandro\\workspace\\esercizio4\\xml");
	   try {
	     NewParserCup p = new NewParserCup(new Lexer(new FileReader(argv[0])));
	     ProgramOp r = (ProgramOp) p.parse().value;
	     //System.out.println(r);
	     XMLVisit(r,f);
	     System.out.println("Albero Creato ----->OK xml<-----");
	     //p.parse();
	   } catch (Exception e) {
	    /* do cleanup here -- possibly rethrow e */
	     e.printStackTrace(); 
	      
	   }
	}
	
	
	private static void XMLVisit(ProgramOp root, File file) throws ParserConfigurationException, FileNotFoundException, UnsupportedEncodingException, TransformerException
	{
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
		Document doc = docBuilder.newDocument();
		Xml visitor = new Xml(doc);
		doc.appendChild((Element)root.accept(visitor)); 
		OutputStream stream = new FileOutputStream(new File("C:\\Users\\Alessandro\\workspace\\esercizio4\\xml"));
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer = tf.newTransformer();
		transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
		transformer.setOutputProperty(OutputKeys.METHOD, "xml");
		transformer.setOutputProperty(OutputKeys.INDENT, "yes");
		transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
		transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
		transformer.transform(new DOMSource(doc), 
				new StreamResult(new OutputStreamWriter(stream, "UTF-8")));
	}	
	
	
	
	
	
	
	
	
	
	
	
}


